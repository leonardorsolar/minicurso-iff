// Função para lidar com o registro de usuário
document
    .getElementById("registerForm")
    .addEventListener("submit", function (event) {
        event.preventDefault() // Evita o envio do formulário padrão

        const name = document.getElementById("registerName").value
        const email = document.getElementById("registerEmail").value
        const password = document.getElementById("registerPassword").value

        const user = { name: name, email: email, password: password }
        console.log(user)

        console.log()

        fetch("http://localhost:3000/api/criarUsuario", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ name, email, password }),
        })
            .then((response) => response.json())
            .then((data) => {
                console.log("Registro bem-sucedido:", data)
                alert("Usuário registrado com sucesso!")
            })
            .catch((error) => {
                console.error("Erro no registro:", error)
                alert("Erro ao registrar usuário.")
            })
    })

// Função para lidar com o login de usuário
document
    .getElementById("loginForm")
    ?.addEventListener("submit", function (event) {
        event.preventDefault() // Evita o envio do formulário padrão

        const email = document.getElementById("loginEmail").value
        const password = document.getElementById("loginPassword").value

        fetch("http://localhost:3000/api/auth", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ email, password }),
        })
            .then((response) => response.json())
            .then((data) => {
                console.log("Login bem-sucedido:", data)
                alert("Login realizado com sucesso!")
                // Redirecionar ou realizar outra ação após o login bem-sucedido
            })
            .catch((error) => {
                console.error("Erro no login:", error)
                alert("Erro ao fazer login.")
            })
    })
